#!/bin/bash

# User Input Validation Script

echo "User Validation Script"
echo "======================"

# Read username from user
read -p "Enter username to check: " username

# Check if user exists in /etc/passwd
if grep -q "^$username:" /etc/passwd; then
    echo "User '$username' exists on the system."
    
    # Display user information
    echo "User Information:"
    grep "^$username:" /etc/passwd | cut -d: -f1,3,5,6
else
    echo "User '$username' does not exist on the system."
    
    # Offer to create user
    read -p "Would you like to create this user? (y/n): " create_user
    
    if [ "$create_user" = "y" ] || [ "$create_user" = "Y" ]; then
        echo "Creating user '$username'..."
        sudo useradd -m "$username"
        
        if [ $? -eq 0 ]; then
            echo "User '$username' created successfully!"
            sudo passwd "$username"
        else
            echo "Error: Failed to create user. Check your privileges."
        fi
    else
        echo "User creation cancelled."
    fi
fi